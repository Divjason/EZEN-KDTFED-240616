import React from "react";

const Default = () => {
  return null;
};

export default Default;
