import React from "react";

const Page = () => {
  return <div>@feed/setting</div>;
};

export default Page;
