import React from "react";

const Page = () => {
  return <div>@feed</div>;
};

export default Page;
