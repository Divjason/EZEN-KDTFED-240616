import React from "react";

const Default = () => {
  return <div>parallel/default</div>;
};

export default Default;
