import React from "react";

const Page = () => {
  return <div>@sidebar</div>;
};

export default Page;
