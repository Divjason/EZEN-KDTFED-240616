import React from "react";

const Default = () => {
  return <div>@sidebar/default</div>;
};

export default Default;
