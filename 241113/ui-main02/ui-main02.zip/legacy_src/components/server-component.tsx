import React from "react";

const ServerComponent = () => {
  console.log("서버컴포넌트!");
  return <div></div>;
};

export default ServerComponent;
