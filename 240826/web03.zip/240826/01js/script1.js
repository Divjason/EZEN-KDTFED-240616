let season = [];

//배열안에 있는 아이템들은 반드시 index값을 가지고 있음!!!
season[0] = "spring";
season[1] = "summer";
season[2] = "fall";
season[3] = "winter";

console.log(season);

// iterable 객체 => iterator // next()
// Map() // Set()

const colors = ["red", "greed", "blue", "white", "black"];

for (let i = 0; i < colors.length; i++) {
  console.log(colors[i]);
}

colors.forEach((color, index, array) => {
  console.log(color);
});

for (let color of colors) {
  console.log(color);
}

// 비동기처리 방식
// callback // Promise // fetch() // async & await
// forEach => 지원!!!
//
