import { createRoot } from "react-dom/client";
// import App from "./App.tsx";
// import App01 from "./App01.tsx";
// import App02 from "./App02.tsx";
import App04 from "./App04.tsx";

createRoot(document.getElementById("root")!).render(<App04 />);
