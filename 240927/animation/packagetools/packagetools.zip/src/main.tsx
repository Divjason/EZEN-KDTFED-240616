import { createRoot } from "react-dom/client";
// import App from "./App.tsx";
// import App01 from "./App01.tsx";
// import App02 from "./App02.tsx";
// import App04 from "./App04.tsx";
// import App06 from "./App06.tsx";
// import App07 from "./App07.tsx";
// import App08 from "./App08.tsx";
import App09 from "./App09.tsx";

createRoot(document.getElementById("root")!).render(<App09 />);
