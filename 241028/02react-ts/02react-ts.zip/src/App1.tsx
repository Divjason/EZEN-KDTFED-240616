import React, { useState } from "react";

const App1 = () => {
  const [value, setValue] = useState("");
  const onChange = (e: React.FormEvent<HTMLInputElement>) => {
    setValue(e.currentTarget.value);
  };
  return (
    <div>
      <form>
        <input
          onChange={onChange}
          value={value}
          type="text"
          placeholder="username"
        />
      </form>
    </div>
  );
};

export default App1;
